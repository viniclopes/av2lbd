package model;

public class JogoQuartas {
	private String timeA;
	private String timeB;
	
	
	public JogoQuartas(String timeA, String timeB) {
		super();
		this.timeA = timeA;
		this.timeB = timeB;
	}
	
	
	public String getTimeA() {
		return timeA;
	}
	public void setTimeA(String timeA) {
		this.timeA = timeA;
	}
	public String getTimeB() {
		return timeB;
	}
	public void setTimeB(String timeB) {
		this.timeB = timeB;
	}
	
	
}
